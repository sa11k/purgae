CREATE DATABASE  IF NOT EXISTS `purgae` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `purgae`;
-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: purgae.net    Database: purgae
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `user_id` bigint NOT NULL AUTO_INCREMENT,
  `game_score` bigint DEFAULT '0',
  `nickname` varchar(16) NOT NULL,
  `profile_image` varchar(100) DEFAULT NULL,
  `profile_public` bit(1) NOT NULL,
  `wallet_address` varchar(50) NOT NULL,
  `today_donation` int DEFAULT '0',
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,259,'난돌고래있다','bafybeiel2uwqcxghpidwo5xazzbatqbc6qms5hkklpt3nhjkci5kofk6yy/434.png',_binary '','0xb1eadd806b2ebc64f6eed68ee6e38e8d27fe76ea',5),(2,222,'이상한 박찬박','bafybeihcwxflrdohbghnqrmg4lfpc5vqhrq2iqslg6fb6z5w2mrp5p7vrq/chan.png',_binary '','0x8b80f8d86a337b45d9a717d4cc8048c58fe2a69b',5),(3,123,'유달래','bafybeihpjixg6vl6iijzn6ikplrxzw7rla3syre7u2jm53najdr4xxxxqu/186.png',_binary '','0xaa016bc18eb5172121ba8eba53840586ec65b588',2),(4,94,'nct드림최고짱','bafybeiaja45njof5fg7duzevr6vcuuo6sil5of6p25abcx2uu6ld6a7hk4/3166.png',_binary '','0xc42d1449259b62cb93a079658640ba7db6ad0d13',1),(5,1140,'민초부먹진순펩시','bafybeiel2uwqcxghpidwo5xazzbatqbc6qms5hkklpt3nhjkci5kofk6yy/200.png',_binary '','0xf7a70bf5441a6b523d35f0002f3bd037bcbc2f62',1),(6,37,'ㅂㄷㅂ',NULL,_binary '','0xca78cac2505bd2829083649f8845132b352e106e',0),(7,395,'둘기','bafybeicy23jvnuccqps7xypwnxyhgkdkpikrf7h4yn2bkdlre7c33pndla/1260.png',_binary '','0x41f0d0083b401ebd2fb4c531742df38343a08455',0),(8,47,'하늘색 금붕어',NULL,_binary '','0x0cc82b7cfc2c63278b875850e155a7a8c9838d38',0),(9,76,'하양색 물고기',NULL,_binary '','0x06929c1d50758cab42b5d7c56071798bf18692e3',0),(10,152,'하늘색 돌고래',NULL,_binary '','0x4863d935ce84baffb20c6739ee404f4406cf2831',0),(11,0,'분홍색 돌고래',NULL,_binary '','0x54d983da6e6841085c5a603515df5c84a184df02',0),(12,259,'귤색 조기',NULL,_binary '','0x065bc2317685a146511faba338708a53fc6d2534',0),(13,539,'사랑해요 코치님','bafybeicy23jvnuccqps7xypwnxyhgkdkpikrf7h4yn2bkdlre7c33pndla/1097.png',_binary '','0xc33300ae6b486b2fddb26dffe772f77262c5763a',2),(14,101,'금색 청어',NULL,_binary '','0xd758cc08ece08fd21af9c2407edda47dd9f774a2',0),(16,110,'참치캔거북귀엽다','bafybeidbknudr2n76xcdebbrzdqkcinbkoghy3uey3c5ypmzpz4otxaflq/86.png',_binary '','0x6e17da5d51ec1c3fb5f9bbcf64c40f9f62a83b43',3),(18,0,'하양색 날치',NULL,_binary '','0xc3b54a34deec8ffd06d8d7c58ec6c2492d8e6f93',0),(19,0,'귤색 연어',NULL,_binary '','0xb53ed77e3cf55c695edc225d606e207ddc206558',0),(20,16,'보라색 방어',NULL,_binary '','0xf033a82e4985a56640447646757f435a33d102be',1),(21,0,'노란색 가오리',NULL,_binary '','0x7355778af72c475ac349f7c3aa0c875fb4957996',0),(22,289,'코치아닙니다',NULL,_binary '','0xaf19d713f679158e1ec20a94a7ead240618f2361',5),(24,0,'살구색 노래미',NULL,_binary '','0xa5878f722f64adbf854b1aec1cec2b28e5a8d2a0',0);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-10-06 13:56:54

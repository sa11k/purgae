CREATE DATABASE  IF NOT EXISTS `purgae` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `purgae`;
-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: purgae.net    Database: purgae
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `like_user`
--

DROP TABLE IF EXISTS `like_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `like_user` (
  `like_id` bigint NOT NULL,
  `from_user_id` bigint DEFAULT NULL,
  `to_user_id` bigint DEFAULT NULL,
  PRIMARY KEY (`like_id`),
  KEY `FKbpdisluuihca0rxqnc9ldo4bu` (`from_user_id`),
  KEY `FKn38ltxjlcs05f4th0hci6497j` (`to_user_id`),
  CONSTRAINT `FKbpdisluuihca0rxqnc9ldo4bu` FOREIGN KEY (`from_user_id`) REFERENCES `user` (`user_id`),
  CONSTRAINT `FKn38ltxjlcs05f4th0hci6497j` FOREIGN KEY (`to_user_id`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `like_user`
--

LOCK TABLES `like_user` WRITE;
/*!40000 ALTER TABLE `like_user` DISABLE KEYS */;
INSERT INTO `like_user` VALUES (16,2,1),(17,1,2),(18,1,4),(19,5,2),(20,5,1),(22,5,3),(23,1,5),(25,1,3),(26,5,4),(27,5,6),(29,1,6),(32,6,1),(40,6,5),(48,4,5),(50,3,4),(52,3,6),(53,3,7),(54,3,1),(56,4,3),(57,8,3),(58,9,8),(60,2,5),(61,6,3),(65,8,9),(76,7,5),(129,4,1),(130,6,13),(182,16,3),(183,16,4),(184,16,5),(187,16,2),(204,2,3),(205,2,16),(206,4,16),(211,16,1),(216,13,6),(217,13,2),(218,13,1),(219,13,5),(220,13,3),(221,13,8),(222,13,16),(232,1,13),(237,16,13),(238,5,7),(239,5,13),(240,5,16),(257,2,13),(263,3,5);
/*!40000 ALTER TABLE `like_user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-10-06 13:56:55
